#!/bin/bash
# ============================================================
#  INSTALL OTOMATIS - VPN Panel (Chanelog Tunnel)
#  Mencakup: clone repo, setup PHP/backend, sisip config nginx,
#  fix haproxy multiplex (kalau aktif), enable nginx.
#  Aman dijalankan di server fresh install script VPN02/xray.
# ============================================================
set -e

# API_ONLY=1 -> pasang API saja (tanpa halaman panel web). Dipakai Panel Worker multi-VPS.
API_ONLY="${API_ONLY:-0}"
[[ "$API_ONLY" == "1" ]] && echo ">>> Mode: API SAJA (tanpa halaman panel web)"

REPO_URL="https://github.com/oghc93/cocote-3x-ui.git"
CLONE_DIR="/opt/xray-panel"
NGINX_CONF="/etc/nginx/conf.d/xray.conf"

echo "=== [1/7] Clone repo & install paket ==="
rm -rf "$CLONE_DIR"
git clone "$REPO_URL" "$CLONE_DIR"
cd "$CLONE_DIR"
apt update -qq
apt install -y php-fpm php-cli jq >/dev/null

echo "=== [2/7] Pasang file backend & panel ==="
mkdir -p /etc/vpn-script/api /var/www/vpn-api
[[ "$API_ONLY" == "1" ]] || mkdir -p /var/www/vpn-panel
cp api/api-cli.sh /etc/vpn-script/api/api-cli.sh
chmod 750 /etc/vpn-script/api/api-cli.sh
chown root:root /etc/vpn-script/api/api-cli.sh
cp api/index.php /var/www/vpn-api/index.php
touch /var/log/vpn-panel-bridge-errors.log
chown www-data:www-data /var/log/vpn-panel-bridge-errors.log
if [[ "$API_ONLY" == "1" ]]; then
  touch /etc/vpn-script/.api-only
else
  cp panel/index.html /var/www/vpn-panel/index.html
  rm -f /etc/vpn-script/.api-only
fi

echo "=== [3/7] Batasi akses sudo & generate API key ==="
cp deploy/sudoers-vpnapi /etc/sudoers.d/vpnapi
chmod 440 /etc/sudoers.d/vpnapi
visudo -c

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
PHP_SOCK=$(ls /run/php/php*-fpm.sock 2>/dev/null | head -1)
# pakai ulang key yang sudah ada (supaya Panel Worker tidak putus); buat baru kalau belum ada
API_KEY=$(cat /etc/vpn-script/api-key.txt 2>/dev/null || true)
[[ -n "$API_KEY" && -z "${NEW_KEY:-}" ]] || API_KEY=$(openssl rand -hex 32)
POOL="/etc/php/$PHP_VER/fpm/pool.d/www.conf"
[[ -f "$POOL" ]] || { echo "ERROR: $POOL tidak ada"; exit 1; }
sed -i '/^env\[VPN_API_KEY\]/d' "$POOL"
echo "env[VPN_API_KEY] = \"$API_KEY\"" >> "$POOL"
mkdir -p /etc/vpn-script
echo "$API_KEY" > /etc/vpn-script/api-key.txt
chmod 600 /etc/vpn-script/api-key.txt
systemctl restart "php$PHP_VER-fpm"

echo "=== [4/7] Sisip config nginx (/api/ dan /panel/) ==="
# Blok panel ditulis ke snippet terpisah + di-include dari config Nginx, supaya
# TIDAK hilang saat script VPN membuat ulang config Nginx (regenerate).
SNIP="/etc/nginx/snippets/vpn-panel-ui.conf"
mkdir -p /etc/nginx/snippets
cat > "$SNIP" <<EOS
# --- VPN PANEL API & UI (dikelola script, aman dari regenerate config) ---
location /api/ {
    fastcgi_pass unix:$PHP_SOCK;
    fastcgi_param SCRIPT_FILENAME /var/www/vpn-api/index.php;
    fastcgi_param QUERY_STRING \$query_string;
    fastcgi_param REQUEST_METHOD \$request_method;
    fastcgi_param CONTENT_TYPE \$content_type;
    fastcgi_param CONTENT_LENGTH \$content_length;
    fastcgi_param REQUEST_URI \$request_uri;
    fastcgi_param HTTP_X_API_KEY \$http_x_api_key;
    fastcgi_param SERVER_SOFTWARE nginx;
    fastcgi_param SERVER_PROTOCOL \$server_protocol;
    fastcgi_index index.php;
}
EOS
if [[ "$API_ONLY" != "1" || -f /var/www/vpn-panel/index.html ]]; then
  cat >> "$SNIP" <<'EOP'
location /panel/ {
    alias /var/www/vpn-panel/;
    index index.html;
    try_files $uri $uri/ /panel/index.html;
}
EOP
fi
if grep -q 'location /panel/' "$NGINX_CONF" 2>/dev/null; then
  echo "Blok panel sudah ada langsung di $NGINX_CONF - dibiarkan."
elif grep -q 'vpn-panel-\*.conf' "$NGINX_CONF" 2>/dev/null; then
  echo "Include snippet panel sudah ada di $NGINX_CONF."
elif grep -q "root /var/www/html;" "$NGINX_CONF" 2>/dev/null; then
  BK_N="$NGINX_CONF.bak.$(date +%Y%m%d%H%M%S)"
  cp "$NGINX_CONF" "$BK_N"
  ANCHOR_LINE=$(grep -n "root /var/www/html;" "$NGINX_CONF" | head -1 | cut -d: -f1)
  awk -v ln="$((ANCHOR_LINE - 1))" 'NR==ln{print "    include /etc/nginx/snippets/vpn-panel-*.conf; # vpn-panel"} {print}' "$BK_N" > "$NGINX_CONF"
  if ! nginx -t; then cp "$BK_N" "$NGINX_CONF"; echo "GAGAL: nginx -t, config dikembalikan"; exit 1; fi
else
  echo "PERINGATAN: pola 'root /var/www/html;' tidak ketemu di $NGINX_CONF"
  echo "Sisip config nginx manual sesuai deploy/DEPLOY.md bagian 1-2."
fi

echo "=== [5/7] Fix haproxy multiplex (kalau aktif) ==="
if [[ -f /etc/vpn-script/.multiplex-443-active ]] && [[ -f /etc/haproxy/haproxy.cfg ]]; then
  if ! grep -q "looks_like_post" /etc/haproxy/haproxy.cfg; then
    cp /etc/haproxy/haproxy.cfg /etc/haproxy/haproxy.cfg.bak.$(date +%Y%m%d%H%M%S)
    awk '
      /^  acl looks_like_http / {
        print "  acl looks_like_get     req.payload(0,4) -m str \"GET \""
        print "  acl looks_like_post    req.payload(0,5) -m str \"POST \""
        print "  acl looks_like_put     req.payload(0,4) -m str \"PUT \""
        print "  acl looks_like_delete  req.payload(0,7) -m str \"DELETE \""
        print "  acl looks_like_head    req.payload(0,5) -m str \"HEAD \""
        print "  acl looks_like_options req.payload(0,8) -m str \"OPTIONS \""
        print "  acl looks_like_patch   req.payload(0,6) -m str \"PATCH \""
        next
      }
      /^  use_backend multiplex_xray if looks_like_http or looks_like_h2$/ {
        print "  use_backend multiplex_xray if looks_like_get or looks_like_post or looks_like_put or looks_like_delete or looks_like_head or looks_like_options or looks_like_patch or looks_like_h2"
        next
      }
      { print }
    ' /etc/haproxy/haproxy.cfg > /tmp/haproxy.cfg.new
    cat /tmp/haproxy.cfg.new > /etc/haproxy/haproxy.cfg
    haproxy -c -f /etc/haproxy/haproxy.cfg
    systemctl reload haproxy
    echo "haproxy.cfg diperbaiki (method selain GET sekarang dikenali)."
  else
    echo "haproxy.cfg sudah benar, tidak perlu diubah."
  fi
else
  echo "Multiplex tidak aktif / haproxy tidak dipakai - lewati."
fi

echo "=== [6/7] Reload nginx & enable auto-start ==="
systemctl reload nginx
systemctl enable nginx >/dev/null 2>&1

echo "=== [7/7] Selesai ==="
DOMAIN=$(grep -oP 'server_name \K[^;]+' "$NGINX_CONF" 2>/dev/null | head -1)
echo ""
echo "================================================================"
echo " INSTALASI SELESAI"
if [[ "$API_ONLY" == "1" ]]; then
  echo " URL API : https://${DOMAIN:-<domain-mu>}/api"
else
  echo " Panel   : https://${DOMAIN:-<domain-mu>}/panel/"
fi
echo " API key : $API_KEY"
echo " (tersimpan di /etc/vpn-script/api-key.txt)"
echo " (simpan API key ini - dibutuhkan saat 'Hubungkan ke server')"
echo "================================================================"
